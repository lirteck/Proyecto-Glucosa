package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class RegistroActivity extends AppCompatActivity {
    Button btnRegistrar;
    EditText nombre, correo, contra;

    ImageView btnRegresar;
    FirebaseFirestore mFirestore;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        mFirestore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // Referenciar vistas
        nombre = findViewById(R.id.edtNombre);
        correo = findViewById(R.id.edtCorreo);
        contra = findViewById(R.id.edtContra);
        btnRegistrar = findViewById(R.id.btnRegistro);
        btnRegresar = findViewById(R.id.img_btnRegresar);
        // Se obtienen los valores ingresados en los campos de texto como cadenas de texto y se eliminan los espacios en blanco alrededor de cada cadena
        // Se verifica que no esten vacios
        // Se verifica que el nombre tenga al menos dos espacios
        // Se verifica que el correo tenga el formato adecuado
        //  Se verifica que la contraseña tenga al menos 6 caracteres
        // Se llama al método registroUsuario() pasandolos como parámetros

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombreUsuario = nombre.getText().toString().trim();
                String correoUsuario = correo.getText().toString().trim();
                String contraUsuario = contra.getText().toString().trim();

                if (nombreUsuario.isEmpty() || correoUsuario.isEmpty() || contraUsuario.isEmpty()) {
                    Toast.makeText(RegistroActivity.this, "Complete los datos", Toast.LENGTH_SHORT).show();
                } else if (countSpaces(nombreUsuario )<2) {
                    Toast.makeText(RegistroActivity.this, "Es necesario ingresar el Nombre Completo", Toast.LENGTH_SHORT).show();
                } else if (!isValidEmail(correoUsuario)) {
                    Toast.makeText(RegistroActivity.this, "Formato de correo electrónico incorrecto", Toast.LENGTH_SHORT).show();
                } else if (contraUsuario.length() < 6) {
                    Toast.makeText(RegistroActivity.this, "La contraseña debe tener al menos 6 caracteres alfanuméricos", Toast.LENGTH_SHORT).show();
                }  else {
                    registroUsuario(nombreUsuario, correoUsuario, contraUsuario);
                }
            }
        });

        // Dirige e inicia a la actividad MainActivity
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistroActivity.this, MainActivity.class));
            }
        });
    }
    // Metodo para la verificar que el nombre que se quiere registrar este completo
    private int countSpaces(String str) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == ' ') {
                count++;
            }
        }
        return count;
    }
    // Se utiliza el método createUserWithEmailAndPassword() de mAuth para crear un nuevo usuario utilizando el correo electrónico y contraseña proporcionados
    // Se obtiene el usuario actualmente autenticado
    // Se actualiza el perfil del usuario con el nombre completo proporcionado utilizando UserProfileChangeRequest
    // Se obtiene el primer nombre del usuario separando el nombre completo por espacios y tomando el primer elemento del arreglo resultante
    // Se crea un mapa con los datos y se guardan en la coleccion "Usuario"

    private void registroUsuario(String nombreUsuario, String correoUsuario, String contraUsuario) {
        mAuth.createUserWithEmailAndPassword(correoUsuario, contraUsuario).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    if (user != null) {
                        // Separar el nombre completo en primer nombre y apellidos
                        String[] nombres = nombreUsuario.split(" ");
                        String primerNombre = nombres[0];

                        UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                .setDisplayName(nombreUsuario)
                                .build();

                        user.updateProfile(profileUpdates)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Log.d("FirebaseAuth", "User profile updated.");
                                        }
                                    }
                                });

                        String id = nombreUsuario.replaceAll("\\s", ""); // Elimina los espacios del nombre para usarlo como ID
                        Map<String, Object> map = new HashMap<>();
                        map.put("id", id);
                        map.put("Nombre", nombreUsuario);
                        map.put("PrimerNombre", primerNombre); // Guardar el primer nombre en Firestore
                        map.put("Correo", correoUsuario);
                        map.put("Contrasena", contraUsuario);

                        mFirestore.collection("Usuario").document(id).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                finish();
                                startActivity(new Intent(RegistroActivity.this, MainActivity.class));
                                Toast.makeText(RegistroActivity.this, "Usuario Registrado Correctamente", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("Firestore", "Error al guardar en Firestore", e);
                                Toast.makeText(RegistroActivity.this, "Error al guardar en Firestore", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } else {
                    Log.e("FirebaseAuth", "Error al crear usuario", task.getException());
                    Toast.makeText(RegistroActivity.this, "Error al crear usuario", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

}
