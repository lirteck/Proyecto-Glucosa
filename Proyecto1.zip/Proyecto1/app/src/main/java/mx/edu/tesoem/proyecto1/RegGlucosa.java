package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import mx.edu.tesoem.proyecto1.model.glucosa;
import mx.edu.tesoem.proyecto1.adapter.glucosaAdapter;

public class RegGlucosa extends AppCompatActivity {

    // Definición de variables de clase
    ImageView img_btnAgregarG;
    ImageView btnRegresar;
    FirebaseFirestore mFirestore;
    RecyclerView mRecycler;
    glucosaAdapter mAdapter;
    Query query;

    // Obtiene el usuario actual de Firebase Authentication
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    String nombreUsuario = user.getDisplayName(); // Obtiene el nombre del usuario
    String userId = nombreUsuario.replaceAll("\\s", ""); // Elimina los espacios en blanco del nombre del usuario para usarlo como ID de documento

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reg_glucosa);

        // Inicializa Firestore
        mFirestore = FirebaseFirestore.getInstance();

        // Inicializa el RecyclerView y establece su diseño
        mRecycler = findViewById(R.id.RecyclerView2);
        mRecycler.setLayoutManager(new LinearLayoutManager(this));

        // Crea una consulta para obtener los registros de glucosa del usuario actual, ordenados por fecha y hora de forma descendente
        query = mFirestore.collection("Usuario").document(userId)
                .collection("registrosGlucosa")
                .orderBy("fechaHora", Query.Direction.DESCENDING);

        // Configura las opciones del adaptador FirestoreRecyclerOptions
        FirestoreRecyclerOptions<glucosa> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<glucosa>()
                        .setQuery(query, glucosa.class).build();

        // Inicializa el adaptador con las opciones configuradas
        mAdapter = new glucosaAdapter(firestoreRecyclerOptions, this);

        // Notifica cambios en los datos al adaptador y establece el adaptador en el RecyclerView
        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);

        // Inicializa los botones de la interfaz de usuario
        img_btnAgregarG = findViewById(R.id.img_btnAgregarG);
        btnRegresar = findViewById(R.id.img_btnRegresar1);

        // Configura el botón para agregar un nuevo registro de glucosa
        img_btnAgregarG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickAgregarP(view); // Llama al método para abrir el fragmento de creación de registro
            }
        });

        // Configura el botón para regresar a la actividad principal
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegGlucosa.this, MainActivity.class)); // Inicia la actividad principal
            }
        });
    }

    // Método para abrir el fragmento de creación de registro de glucosa
    public void onClickAgregarP(View view) {
        CrearRegGlucosa cr = new CrearRegGlucosa();
        cr.show(getSupportFragmentManager(), "insertar registro");
    }

    // Métodos para manejar el ciclo de vida del adaptador y la escucha de cambios en los datos
    @Override
    protected void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.stopListening();
    }
}
