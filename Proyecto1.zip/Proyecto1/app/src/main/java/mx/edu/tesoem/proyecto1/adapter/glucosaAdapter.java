package mx.edu.tesoem.proyecto1.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import mx.edu.tesoem.proyecto1.CrearRegGlucosa;
import mx.edu.tesoem.proyecto1.R;
import mx.edu.tesoem.proyecto1.model.glucosa;

public class glucosaAdapter extends FirestoreRecyclerAdapter<glucosa, glucosaAdapter.ViewHolder> {

    private Context mContext;

    public glucosaAdapter(@NonNull FirestoreRecyclerOptions<glucosa> options, Context context) {
        super(options);
        this.mContext = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull glucosa model) {
        holder.bind(model);
        int imagen = obtenerImagenPorValor(model.getValor());
        holder.descripcion.setImageResource(imagen);
        holder.imageViewP4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSnapshots().getSnapshot(position).getReference().delete();
            }
        });

        holder.imageViewP5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener la posición del elemento clickeado
                int position = holder.getAdapterPosition();
                // Obtener el ID del documento del registro
                String documentId = getSnapshots().getSnapshot(position).getId();
                // Obtener la fecha y valor del registro
                String fechaHora = model.getFechaHora();
                int valor = model.getValor();

                // Abrir CrearRegGlucosa con los datos del registro
                CrearRegGlucosa fragment = new CrearRegGlucosa();
                Bundle bundle = new Bundle();
                bundle.putString("documentId", documentId);
                bundle.putString("fechaHora", fechaHora);
                bundle.putInt("valor", valor);
                fragment.setArguments(bundle);
                fragment.show(((FragmentActivity) mContext).getSupportFragmentManager(), "editar registro");
            }
        });


    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_glucosa, parent, false);
        return new ViewHolder(view);
    }

    private int obtenerImagenPorValor(int valor) {
        if (valor >= 70 && valor <= 75) {
            return R.drawable.bajo;
        } else if (valor > 75 && valor <= 126) {
            return R.drawable.normal;
        } else if (valor > 126 && valor <= 154) {
            return R.drawable.regular;
        } else if (valor > 154 && valor <= 212) {
            return R.drawable.alto;
        } else if (valor > 212 && valor <= 500) {
            return R.drawable.critico;
        } else {
            return R.drawable.perfil;
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView fechaHoraTextView;
        private TextView valorTextView;
        private ImageView descripcion;
        private ImageView imageViewP4;

        private  ImageView imageViewP5;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fechaHoraTextView = itemView.findViewById(R.id.txtFyH);
            valorTextView = itemView.findViewById(R.id.txtIndicador);
            descripcion = itemView.findViewById(R.id.descripcion);
            imageViewP4 = itemView.findViewById(R.id.imageView4);
            imageViewP5 = itemView.findViewById(R.id.imageView5);
        }

        public void bind(glucosa model) {
            fechaHoraTextView.setText(model.getFechaHora());
            valorTextView.setText(String.valueOf(model.getValor()));
        }

    }

}
