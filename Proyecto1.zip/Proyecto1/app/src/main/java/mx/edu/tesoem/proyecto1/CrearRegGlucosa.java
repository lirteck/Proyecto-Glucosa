package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CrearRegGlucosa extends DialogFragment {

    TextView txtFechaHora;
    NumberPicker numberPicker;
    Button btnEnviarReg;
    FirebaseFirestore mfirestore;
    String documentId;
    String userId;
    ImageView btnRegresar;
    int valor;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_crear_reg_glucosa, container, false);
        mfirestore = FirebaseFirestore.getInstance();

        // Referenciar vistas
        txtFechaHora = v.findViewById(R.id.txtFechaHora);
        numberPicker = v.findViewById(R.id.numPickerr);
        btnEnviarReg = v.findViewById(R.id.btn_EnviarReg);
        btnRegresar = v.findViewById(R.id.img_btnRegresar6);

        Bundle bundle = getArguments();
        if (bundle != null) {
            documentId = bundle.getString("documentId");
            valor = bundle.getInt("valor", 70); // valor predeterminado
        }

        // Configurar NumberPicker
        numberPicker.setMinValue(70);
        numberPicker.setMaxValue(400);
        numberPicker.setWrapSelectorWheel(true);
        numberPicker.setValue(valor);

        // Obtener y mostrar la fecha y hora actual
        String fechaHoraActual = obtenerFechaHoraActual();
        txtFechaHora.setText(fechaHoraActual);

        // Definir las imágenes según los rangos
        final ImageView imageView = v.findViewById(R.id.imageView);

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                Log.d("NumberPicker", "Valor seleccionado: " + newVal);
                if (newVal >= 70 && newVal <= 75) {
                    imageView.setImageResource(R.drawable.bajo);
                } else if (newVal > 75 && newVal <= 126) {
                    imageView.setImageResource(R.drawable.normal);
                } else if (newVal > 126 && newVal <= 154) {
                    imageView.setImageResource(R.drawable.regular);
                } else if (newVal > 154 && newVal <= 212) {
                    imageView.setImageResource(R.drawable.alto);
                } else if (newVal > 212 && newVal <= 400) { // Cambiado a 400 para coincidir con el rango máximo
                    imageView.setImageResource(R.drawable.critico);
                }
            }
        });


        // Obtiene el valor del numberPicker, si hay un documento valido se actualiza con el valor seleccionado, si no hay se envia el valor a un nuevo registro


        btnEnviarReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int valorSeleccionado = numberPicker.getValue();
                if (documentId != null && !documentId.isEmpty()) {
                    actualizarReg(documentId, valorSeleccionado);
                } else {
                    enviarReg(valorSeleccionado);
                }
            }
        });

        // Dirige e inicia a la actividad RegGlucosa
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), RegGlucosa.class);
                startActivity(intent);
            }
        });

        return v;
    }

    // Obtiene la instancia del usuario actualmente autenticado a través de Firebase Authentication
    // Verifica que el usuario no sea nulo, obtiene su nombre de usuario y lo utiliza para construir una identificación de usuario al eliminar los espacios en blanco
    // Se obtiene una referencia al documento del usuario en la colección "Usuario" y una referencia a la subcolección "registrosGlucosa"
    // Se crea un mapa de datos y se añaden a un nuevo documeto

    private void enviarReg(int valor) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            userId = nombreUsuario.replaceAll("\\s", "");
            DocumentReference userDocRef = mfirestore.collection("Usuario").document(userId);
            CollectionReference registrosGlucosaRef = userDocRef.collection("registrosGlucosa");

            Map<String, Object> datos = new HashMap<>();
            datos.put("fechaHora", obtenerFechaHoraActual());
            datos.put("valor", valor);

            registrosGlucosaRef.add(datos)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Toast.makeText(getContext(), "Datos registrados exitosamente", Toast.LENGTH_SHORT).show();
                            dismiss();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getContext(), "Error al registrar los datos", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    // Obtiene la instancia del usuario actualmente autenticado a través de Firebase Authentication
    // Verifica que el usuario no sea nulo, obtiene su nombre de usuario y lo utiliza para construir una identificación de usuario al eliminar los espacios en blanco
    // Se obtiene una referencia al documento de registro específico dentro de la subcolección "registrosGlucosa" del usuario
    // Se crea nuevament el mapa de datos con los datos y se actualiza
    private void actualizarReg(String documentId, int valor) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");
            if (userId != null && !userId.isEmpty()) {
                DocumentReference regDocRef = mfirestore.collection("Usuario")
                        .document(userId).collection("registrosGlucosa").document(documentId);

                Map<String, Object> datos = new HashMap<>();
                datos.put("fechaHora", obtenerFechaHoraActual());
                datos.put("valor", valor);

                regDocRef.update(datos)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(getContext(), "Registro actualizado exitosamente", Toast.LENGTH_SHORT).show();
                                dismiss();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getContext(), "Error al actualizar el registro", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        }
    }
    // Metodo para obtener la fecha y la hora

    private String obtenerFechaHoraActual() {
        Date fechaHoraActual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        return formato.format(fechaHoraActual);
    }
}
