package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegistrarDatosExtrasU extends DialogFragment {

    // Definición de variables de clase
    EditText edtPeso, edtAltura, edtEdad;
    ImageView btnRegresar;
    Button btn_DatosE;
    private FirebaseFirestore mfirestore;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Infla el diseño del fragmento
        View v = inflater.inflate(R.layout.fragment_registrar_datos_extras_u, container, false);
        mfirestore = FirebaseFirestore.getInstance(); // Inicializa Firestore

        // Referenciar vistas
        edtPeso = v.findViewById(R.id.edtPeso);
        edtAltura = v.findViewById(R.id.edtAltura);
        edtEdad = v.findViewById(R.id.edtEdad);
        btn_DatosE = v.findViewById(R.id.btn_DatosE);
        btnRegresar = v.findViewById(R.id.img_btnRegresar4);

        // Configura el botón para registrar datos extra
        btn_DatosE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String peso = edtPeso.getText().toString();
                String altura = edtAltura.getText().toString();
                String edad = edtEdad.getText().toString();

                // Verifica que todos los campos estén completos
                if (!peso.isEmpty() && !altura.isEmpty() && !edad.isEmpty()) {
                    enviarRegDatosE(peso, altura, edad); // Envía los datos extra para ser registrados
                } else {
                    Toast.makeText(getContext(), "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Configura el botón para regresar a la actividad Perfil
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Perfil.class);
                startActivity(intent);
            }
        });

        return v;
    }

    // Método para enviar los datos extra del usuario a Firestore
    private void enviarRegDatosE(String peso, String altura, String edad) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); // Obtiene el usuario actual
        if (user != null) {
            String nombreUsuario = user.getDisplayName(); // Obtiene el nombre del usuario
            String userId = nombreUsuario.replaceAll("\\s", ""); // Elimina los espacios en blanco del nombre del usuario para usarlo como ID de documento

            // Obtiene una referencia al documento del usuario en la colección "Usuario" y una referencia a la subcolección "datosExtra"
            DocumentReference userDocRef = mfirestore.collection("Usuario").document(userId);
            CollectionReference datosExtraRef = userDocRef.collection("datosExtra");

            // Crea un mapa de datos con el peso, altura y edad
            Map<String, Object> datos = new HashMap<>();
            datos.put("peso", peso);
            datos.put("altura", altura);
            datos.put("edad", edad);

            // Añade los datos a la subcolección "datosExtra" y maneja el éxito o fallo de la operación
            datosExtraRef.add(datos)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            // Si la actividad actual es una instancia de Perfil, carga los datos extra del usuario
                            if (getActivity() instanceof Perfil) {
                                ((Perfil) getActivity()).cargarDatosExtraUsuario();
                            }
                            Toast.makeText(getContext(), "Datos registrados exitosamente", Toast.LENGTH_SHORT).show();
                            dismiss(); // Cierra el fragmento
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getContext(), "Error al registrar los datos", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
}
