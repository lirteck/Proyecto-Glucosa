package mx.edu.tesoem.proyecto1.model;

public class glucosa {
    String fechaHora;
    int valor; // Cambiado a Long

    public glucosa(String fechaHora, int valor) {
        this.fechaHora = fechaHora;
        this.valor = valor;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public glucosa (){

    }
}

