package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class Perfil extends AppCompatActivity {

    TextView txtNombre, txtCorreo, txtPeso, txtAltura, txtEdad;
    ImageView img_btnAgregarDatos;
    ImageView btnRegresar;
    FirebaseFirestore mFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_perfil);

        mFirestore = FirebaseFirestore.getInstance();

        // Referenciar vistas

        txtNombre = findViewById(R.id.txtNombreP);
        txtCorreo = findViewById(R.id.txtCorreoP);
        txtPeso = findViewById(R.id.txtPesoP);
        txtAltura = findViewById(R.id.txtAlturaP);
        txtEdad = findViewById(R.id.txtEdadP);
        btnRegresar = findViewById(R.id.img_btnRegresar3);



        img_btnAgregarDatos = findViewById(R.id.img_btnAgregarDatos);

        img_btnAgregarDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickAgregarDatosExtras(view);
            }
        });

        // Dirige e inicia a la actividad MainActivity

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Perfil.this, MainActivity.class));
            }
        });
    }

    // Metodo que se llama cuando la actividad vuelve a estar en primer plano
    // Llama al método cargarDatosUsuario() para cargar los datos del usuario

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatosUsuario();
    }

    // Obtiene el usuario actualmente autenticado
    // Si el usuario no es nulo, obtiene su nombre completo y correo electrónico y los establece en los textView
    // Llama al metodo cargarDatosExtraUsuario()

    private void cargarDatosUsuario() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreCompleto = user.getDisplayName();
            String correo = user.getEmail();
            txtNombre.setText(nombreCompleto);
            txtCorreo.setText(correo);

            cargarDatosExtraUsuario();
        }
    }

    // Obtiene la instancia del usuario actualmente autenticado a través de Firebase Authentication
    // Verifica que el usuario no sea nulo, obtiene su nombre de usuario y lo utiliza para construir una identificación de usuario al eliminar los espacios en blanco
    // Realiza una consulta para obtener datos adicionales del usuario desde la colección "datosExtra"
    // Itera sobre los documentos devueltos por la consulta y establece el peso, altura y edad en los TextView correspondientes


    public void cargarDatosExtraUsuario() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");

            DocumentReference userDocRef = mFirestore.collection("Usuario").document(userId);
            userDocRef.collection("datosExtra").get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    String peso = document.getString("peso");
                                    String altura = document.getString("altura");
                                    String edad = document.getString("edad");
                                    txtPeso.setText(peso);
                                    txtAltura.setText(altura);
                                    txtEdad.setText(edad);
                                }
                            } else {
                                Toast.makeText(Perfil.this, "Error al cargar datos extra", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    // Se llama cuando se hace clic en un botón para agregar datos extras

    public void onClickAgregarDatosExtras(View view) {
        RegistrarDatosExtrasU cr = new RegistrarDatosExtrasU();
        cr.show(getSupportFragmentManager(), "insertar registro");
    }
}
