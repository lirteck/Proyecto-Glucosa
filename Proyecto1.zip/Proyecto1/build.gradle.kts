buildscript {
    repositories {
        google()
        // otras repositorios si los tienes
    }

    dependencies {

        classpath("com.android.tools.build:gradle:4.2.0")
        classpath("com.google.gms:google-services:4.4.1")
    }
}


plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.google.gms.google.services) apply false


}